<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>TIRTA ARUNA COTTAGE</title>
    <style>
        table,th,td {
            text-align:center;
            background:#f3ffc9;
            padding:3px;
        }
    </style>
</head>
<body>
    <table>
        <tr>
            <th colspan="7" style="background:#1BA0DC;">
                <h1>
                ESPEEDBOAT<br>
                E-MAIL
                </h1>
                <P>
                Universitas Udayana <br>
                </P>
            </th>
        </tr>
        
        <tr>
            <th colspan="7" >
                <p>Hai <?php echo e($data['nama']); ?>!, Mohon untuk mengakses link berikut ini untuk memverifikasi account Espeedboat anda</p>
            </th>
        </tr>
                <td colspan="7">
                    <a href="<?php echo e($data['link']); ?>">LINK VERIFIKASI ACCOUNT</a>
                </td>
        <tr>
            <td colspan="7" >
                <p></p>
            </td>
        </tr>
        
        <tr>
            <td colspan="7" style="background:#1BA0DC;">
                <p style="margin-bottom:20px;">Big Regrads</p>
                <p>TEAM TOPSUS TICKETING</p>
            </td>
        </tr>
    </table>
</body>
</html><?php /**PATH C:\xampp\htdocs\ESpeedBoatAndroid\core\resources\views/email/VerifikasiUser.blade.php ENDPATH**/ ?>